import os

# Don't use your own account for this, this will delete pretty much everything you have!
TOKEN = os.environ.get('TYPEFORM_TOKEN')
