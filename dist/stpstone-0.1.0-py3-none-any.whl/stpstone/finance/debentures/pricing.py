### LIBRARY TO PRICE DEBENTURES ###

class DebeturesBR:

    def duration(self):
        '''
        '''
        pass
