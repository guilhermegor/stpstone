### 1.1.0 (2019-06-29)

##### Chores

* **requirements:**  add requirements file and add to dev requirements (35e514c3)
* **LICENSE:**  re-add original package mantainer (7223e1d9)

##### New Features

* **Responses:**  add responses api, fixes #6 (aeb12487)

#### 1.0.2 (2019-02-22)

##### Build System / Dependencies

* **coveralls:**  configure coveralls for code coverage (931b537b)

##### Refactors

* **Client:**  return parsed `Response` or raise an `Exception` instead of passing through `Response` (66da5080)

#### 1.0.1 (2019-02-21)

##### Chores

* **release:**  major version release (ff274e37)

##### Documentation Changes

*  set setup `long_description_content_type` as `'text/markdown'` (579e739c)

##### New Features

*  update to support new forms api (9c272626)

## 1.0.0 (2019-02-21)

##### New Features

*  update to support new forms api (9c272626)

### 0.1.1 (2017-05-22)

### 0.1.0 (2017-02-24)
